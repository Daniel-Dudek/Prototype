package es.businessmind.prototype;

import java.io.Serializable;

public class Items implements Serializable {
    private String titleItem;
    private int imgFoto;
    private String descripcion;

    public Items(String titleItem, int imgFoto, String descripcion) {
        this.titleItem = titleItem;
        this.imgFoto = imgFoto;
        this.descripcion = descripcion;
    }

    public String getTitleItem() { return titleItem; }

    public int getImgFoto() { return imgFoto; }

    public String getDescripcion() { return descripcion; }
}
