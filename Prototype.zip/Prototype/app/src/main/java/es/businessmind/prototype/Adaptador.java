package es.businessmind.prototype;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class Adaptador extends BaseAdapter {
    private Context context;
    private ArrayList<Items> listItems;

    public Adaptador(Context context, ArrayList<Items> listItems) {
        this.context = context;
        this.listItems = listItems;
    }

    // Datos que se van a cargar (asociado con el arraylist)
    @Override
    public int getCount() {
        return listItems.size();
    }

    // Devuelve de listItems la posicion
    @Override
    public Object getItem(int position) {
        return listItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    // Se crea cada Item en una View
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final Items Item = (Items) getItem(position);

        convertView = LayoutInflater.from(context).inflate(R.layout.list_items_store, null);
        ImageView imgItem = (ImageView) convertView.findViewById(R.id.itemImageView);
        TextView titleItem = (TextView) convertView.findViewById(R.id.tituloItem);
        TextView descripcionItem = (TextView) convertView.findViewById(R.id.descripciónItem);

        imgItem.setImageResource(Item.getImgFoto());
        titleItem.setText(Item.getTitleItem());
        descripcionItem.setText(Item.getDescripcion());

        // Evento clickable de los items
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailsItems.class);
                intent.putExtra("itemData", Item);
                context.startActivity(intent);
            }
        });

        return convertView;
    }
}
