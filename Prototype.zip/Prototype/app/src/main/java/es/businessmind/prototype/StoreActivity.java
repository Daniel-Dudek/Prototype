package es.businessmind.prototype;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;



import java.util.ArrayList;

public class StoreActivity extends AppCompatActivity {
    private ListView listViewItems;
    private Adaptador adaptador;
    private ArrayList<Items> arrayItems;
    private Menu menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store);

        listViewItems = findViewById(R.id.listaItems);
        arrayItems = GetArrayItems();
        adaptador = new Adaptador(this, arrayItems);
        listViewItems.setAdapter(adaptador);

        Toolbar myToolbar = findViewById(R.id.appbar);
        setSupportActionBar(myToolbar);
        /*
        //Evento clickable de los items
        listViewItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(StoreActivity.this, DetailsItems.class);
                intent.putExtra("itemData", arrayItems.get(position));
                startActivity(intent);
            }
        });*/
    }

    private ArrayList<Items> GetArrayItems(){
        ArrayList<Items> listItems = new ArrayList<>();
        listItems.add(new Items("Botas de Ski", R.drawable.image, "Esto es un ejempplo para ver si funciona bien"));
        listItems.add(new Items("Tabla de Snow", R.drawable.image, "Esto es un ejempplo para ver si funciona bien"));
        listItems.add(new Items("Mochila", R.drawable.image, "Esto es un ejempplo para ver si funciona bien"));
        listItems.add(new Items("Guantes", R.drawable.image, "Esto es un ejempplo para ver si funciona bien"));
        listItems.add(new Items("Gafas", R.drawable.image, "Esto es un ejempplo para ver si funciona bien"));

        return listItems;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
       getMenuInflater().inflate(R.menu.appbar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.login:
                //login();
                return true;

            case R.id.item1:
                startActivity(new Intent(this, MainActivity.class));
                return true;
            case R.id.item2:
                startActivity(new Intent(this, MainActivity.class));
                return true;
            case R.id.item3:
                startActivity(new Intent(this, MainActivity.class));
                return true;

        }
        return super.onOptionsItemSelected(item);
    }
}